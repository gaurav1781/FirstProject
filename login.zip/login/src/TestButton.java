import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class TestButton extends JPanel
{
        private JFrame mainFrame;
        //private JButton btnShow ;
        private JButton btnNew;
        private JButton Login;
        private JTextField usertext;
        private JTextField userpass;

        public TestButton() {
            mainFrame = new JFrame("Test Button");
            JButton btnShow = new JButton("Show New Button");
            btnNew = new JButton("This is New Button");
            Login=new JButton("Click");
            userpass=new JTextField();
            usertext=new JTextField();
            Container c = mainFrame.getContentPane();
            c.setLayout(new FlowLayout());
            c.add(btnShow);
            c.add(btnNew);
            c.add(Login);
            c.add(userpass);
            c.add(usertext);
            btnNew.setVisible(false);
            Login.setVisible(false);
            mainFrame.addWindowListener(new WindowAdapter()
            {
                public void windowClosing(WindowEvent e) {
                    System.exit(0);
                }
            }
            );

            mainFrame.setSize(850, 650);
            usertext.setBounds(10,78,400,400);
            usertext.setSize(20,40);
            userpass.setBounds(20,117,620,140);
            mainFrame.setLocationRelativeTo(null);
            mainFrame.setResizable(false);
            mainFrame.setVisible(true);
            ShowButtonHandler ghandler = new ShowButtonHandler();
            btnShow.addActionListener(ghandler);
        }

        class ShowButtonHandler implements ActionListener {
            public void actionPerformed(ActionEvent e) {
                //btnNew.setVisible(true);
                try
                {
                    String url="jdbc:mysql://localhost:3306/world";
                    String username="root";
                    String password="newpass";
                    Connection conn= DriverManager.getConnection(url,username,password);
                    String Name=usertext.getText();
                    String ID=userpass.getText();
                    Statement stmt=conn.createStatement();
                    String sql="select * from city where Name='"+Name+"' and ID='"+ID+"'";
                    ResultSet set=stmt.executeQuery(sql);
                    if(set.next())
                        JOptionPane.showMessageDialog(null,"Login success");
                    else
                        JOptionPane.showMessageDialog(null,"Incorrect Username or Password");

                }catch (Exception exception)
                {
                    System.out.println(exception.getMessage());
                }
                //Login.setVisible(true);
            }
        }

        public static void main(String args[]) {
            TestButton app = new TestButton();
        }
    }


package com.company;

import javax.swing.*;
import javax.xml.transform.Result;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Login_GUI extends JFrame {
    public JPanel first_panel;
    private JButton usernameButton;
    private JButton passwordButton;
    private JTextField textField1;
    private JPasswordField passwordField1;
    public JButton loginButton;
    //public JFrame frame;

    public Login_GUI() {
        JTextField textField1 = new JTextField();
        textField1.setBounds(10,78,198,150);
        JPasswordField passwordField1 = new JPasswordField();
        passwordField1.setBounds(20,117,620,14);

        JFrame frame=new JFrame("New");
        frame.setContentPane(new Login_GUI().first_panel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        loginButton=new JButton();
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try
                {

                    Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/world");

                    String Name=textField1.getText();
                    String ID=passwordField1.getText();
                    Statement stmt=conn.createStatement();
                    String sql="select * from city where Name='"+Name+"' and ID='"+ID+"'";
                    ResultSet set=stmt.executeQuery(sql);
                    if(set.next())
                        JOptionPane.showMessageDialog(null,"Login success");
                    else
                        JOptionPane.showMessageDialog(null,"Incorrect Suceess");

                }catch (Exception exception)
                {
                    System.out.println(exception.getMessage());
                }
            }
        });
    }
}

import javax.swing.*;

public class Login_GUI {
    private JButton usernameButton;
    private JButton passwordButton;
    private JTextField textField1;
    private JPasswordField passwordField1;
    private JButton loginButton;
}

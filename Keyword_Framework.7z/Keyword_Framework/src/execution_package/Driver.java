package execution_package;
import java.io.FileInputStream;
import java.util.Properties;
import config.Constants;
import config.keywords;
import utilities.External_excel;

public class Driver
{
	public static Properties OR;
	public static String sactionkeyword;
	public static String Pageobject;
	public static void main(String[] args) throws Exception
	{
//String filepath="D:\\Software\\Java Workspace\\Master.xlsx";
		String filepath=Constants.Excelpath;
		String repo_path=Constants.OR_path;
		FileInputStream fs=new FileInputStream(repo_path);
		OR=new Properties(System.getProperties());
		OR.load(fs);
		External_excel.setExcelFile(filepath, "Steps");
		for(int i=1;i<=3;i++)
			{
			sactionkeyword=External_excel.getExcelData(i,4);
			sactionkeyword=External_excel.getExcelData(i, Constants.Col_Action);
			Pageobject=External_excel.getExcelData(i, Constants.Col_Object);
			System.out.println("Page Object is" + " " + Pageobject);
				if(sactionkeyword.equals("openbrowser"))
					{
					keywords.openbrowser();
					}
				else if(sactionkeyword.equals("navigate"))
				{
					keywords.navigate();
				}
				else if(sactionkeyword.equals("input_username"))
				{
					keywords.input_username(Pageobject);
				}
			}
	}
	
}

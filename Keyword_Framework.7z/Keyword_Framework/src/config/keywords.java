package config;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import static execution_package.Driver.OR;

public class keywords 
{
	static WebDriver dr;
public static void openbrowser()
{
	System.setProperty("webdriver.gecko.driver","D:\\Selenium\\Drivers\\geckodriver.exe");
	System.setProperty("webdriver.chrome.driver","D:\\Selenium\\Drivers\\chromedriver.exe");
	//dr=new FirefoxDriver();
	dr=new ChromeDriver();
}
public static void navigate()
{
	dr.get("http://www.google.com");
	dr.manage().window().maximize();
}
public static void input_username(String object)
{
	dr.findElement(By.xpath(OR.getProperty(object))).sendKeys(Constants.username);
}

}

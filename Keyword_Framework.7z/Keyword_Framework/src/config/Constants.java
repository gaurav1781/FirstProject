package config;

public class Constants
{
    public static final String Excelpath="D:\\Software\\Java Workspace\\Master.xlsx";
    public static final String URL="http:\\www.google.com";
    public static final String OR_path="D:\\Software\\Java Workspace\\Keyword_Framework\\src\\config\\OR.txt";
    public static final String username="gaurav145";
    public static final int Col_TestCaseId=0;
    public static final int Col_TestStepId=1;
    public static final int Col_Object=3;
    public static final int Col_Action=4;
}
